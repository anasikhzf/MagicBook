package com.example.magicbook_projekakhirpember

data class viewpagerdata(
    val imageUrl: Int
)
