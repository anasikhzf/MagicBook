package com.example.magicbook_projekakhirpember

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class item_viewpager : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.item_slide)
    }
}