package com.example.magicbook_projekakhirpember.data

class HiburanData (
    val title: String,
    val penulis: String,
    val description: String,
    val image: Int
)